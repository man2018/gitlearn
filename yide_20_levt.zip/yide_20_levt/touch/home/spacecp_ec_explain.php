<?php exit('Access Denied');?>	
<!--{template common/header}-->
<div class="tip loginbox loginpop p5" id="floatlayout_explain" style="max-height:400px; overflow-y:scroll;">
	<h2 class="log_tit" id="return_explain">{lang eccredit_needexplanation}</h2>
	<form method="post" autocomplete="off" id="explainform_$id" action="home.php?mod=spacecp&ac=eccredit&op=explain&explainsubmit=yes">
		<dt class="mpt">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="id" value="$id" />
			<textarea name="explanation" class="px pxbg"></textarea>
		</dt>
		<dd>
			<button class="z button formdialog" type="button" name="explainsubmit" value="true"><span>{lang submit}</span></button>
			<button class="y button" type="button" value="true" onclick="popup.close();"><span>{lang close}</span></button>
		</dd>
	</form>
</div>
<!--{template common/footer}-->
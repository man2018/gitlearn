<?php exit('Access Denied');?>	
<div class="header cl">
	<div class="mz"><a href="javascript:history.back();"><i class="dm-c-left"></i></a></div>
	<h2><!--{template home/spacecp_header_name}--></h2>
	<div class="my"><a href="index.php"><i class="ydicon icon-ydshouye"></i></a></div>
</div>

<div class="dhnav_box">
	<div id="dhnav">
		<div id="dhnav_li">
		<ul class="swiper-wrapper">
			<!--{template home/spacecp_footer}-->
		</ul>
		</div>
	</div>
</div>

<script>if($("#dhnav_li .mon").length>0){var discuz_nav=$("#dhnav_li .mon").offset().left+$("#dhnav_li .mon").width()>=$(window).width()?$("#dhnav_li .mon").index():0}else{var discuz_nav=0}new Swiper('#dhnav_li',{freeMode:true,slidesPerView:'auto',initialSlide:discuz_nav,onTouchMove:function(swiper){Discuz_Touch_on=0},onTouchEnd:function(swiper){Discuz_Touch_on=1},});</script>

<div class="bodybox p10 cl" style="padding-top: 0 !important;">

<?php exit('Access Denied');?>	

<!--{if $value['msgfromid'] != $_G['uid']}-->
<div class="friend_msg cl">
	<div class="yide_fs_avatar">
		<a href="home.php?mod=space&uid={$value['msgfromid']}&do=profile">
			<img src="<!--{avatar($value['msgfromid'], 'small', true)}-->" class="vm">
		</a>
	</div>
	<div class="dialog_grey">
		<div class="date"><!--{date($value['dateline'], 'u')}--></div>
		<div class="dialog_c">$value['message']</div>
	</div>
</div>
<!--{else}-->
<div class="self_msg cl">
	<div class="dialog_green">			
		<div class="date"><!--{date($value['dateline'], 'u')}--></div>
		<div class="dialog_c">$value['message']</div>
	</div>
	<div class="yide_fs_avatar">
		<a href="home.php?mod=space&uid={$value['msgfromid']}&do=profile">
			<img src="<!--{avatar($value['msgfromid'], 'small', true)}-->" class="vm">
		</a>
	</div>
</div>
<!--{/if}-->
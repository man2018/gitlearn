<?php exit('Access Denied');?>	
<!--{template common/header}-->
<!--{template home/spacecp_header}-->

<!--{if $order_list}-->
<div class="home_credit_log mt10 mb10 cl">
	<ul>
		<!--{loop $order_list $order}-->
		<li class="cl">
			<p class="flex-box align-items-center justify-content-between">
				<span>{$order['type_name']}</span>
				<span class="home-order-status-{$order['status']}">
					{$order['amount']}
					<!--{if $order['status'] == 2}-->
					<em> ({$order['status_name']})</em>
					<!--{elseif !$order['status']}-->
					<a href="{$_G['siteurl']}home.php?mod=spacecp&ac=payment&op=pay&order_id={$order['id']}"> ({$order['status_name']})</a>
					<!--{/if}-->
				</span>
			</p>
			<p class="flex-box align-items-center justify-content-between mt5">
				<span class="txt">
					{$order['subject']}
					<!--{if $order['description']}-->
							<br/>{$order['description']}
					<!--{/if}-->
				</span>
				<span class="mtime">{$order['dateline']}</span>
			</p>
		</li>
		<!--{/loop}-->
	</ul>
	<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
</div>
<!--{else}-->
<div class="empty-box mt10 cl">
	<h4>{lang doing_no_replay}</h4>
</div>
<!--{/if}-->
</div>
<!--{template common/footer}-->
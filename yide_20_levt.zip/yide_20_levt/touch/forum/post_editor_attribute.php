<?php exit('Access Denied');?>	

<!--{hook/post_attribute_extra_mobile}-->
<div class="setbox" id="post_extra_c">
	<div id="extra_additional_c" class="yide_extra_additional exfm cl" style="display: block;">
		<ul class="cl">
			<li>
				<!--{if $_GET['action'] != 'edit'}-->
					<!--{if $_G['group']['allowanonymous']}--><label for="isanonymous"><input type="checkbox" name="isanonymous" id="isanonymous" class="pc" value="1" />{lang post_anonymous}</label><!--{/if}-->
				<!--{else}-->
					<!--{if $_G['group']['allowanonymous'] || (!$_G['group']['allowanonymous'] && $orig['anonymous'])}--><label for="isanonymous"><input type="checkbox" name="isanonymous" id="isanonymous" class="pc" value="1" {if $orig['anonymous']}checked="checked"{/if} />{lang post_anonymous}</label><!--{/if}-->
				<!--{/if}-->
			</li>
			<!--{if $_GET['action'] == 'newthread' || $_GET['action'] == 'edit' && $isfirstpost}-->
			<li><label for="hiddenreplies"><input type="checkbox" name="hiddenreplies" id="hiddenreplies" class="pc"{if $thread['hiddenreplies']} checked="checked"{/if} value="1">{lang hiddenreplies}</label></li>
			<!--{/if}-->
			<!--{if $_G['uid'] && ($_GET['action'] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost) && $special != 3}-->
			<li><label for="ordertype"><input type="checkbox" name="ordertype" id="ordertype" class="pc" value="1" $ordertypecheck />{lang post_descviewdefault}</label></li>
			<!--{/if}-->
			<!--{if ($_GET['action'] == 'newthread' || $_GET['action'] == 'edit' && $isfirstpost)}-->
			<li><label for="allownoticeauthor"><input type="checkbox" name="allownoticeauthor" id="allownoticeauthor" class="pc" value="1"{if $allownoticeauthor} checked="checked"{/if} />{lang post_noticeauthor}</label></li>
			<!--{/if}-->
			<!--{if $_GET['action'] != 'edit' && helper_access::check_module('feed') && $_G['forum']['allowfeed']}-->
			<li><label for="addfeed"><input type="checkbox" name="addfeed" id="addfeed" class="pc" value="1" $addfeedcheck>{lang addfeed}</label></li>
			<!--{/if}-->
			<li><label for="usesig"><input type="checkbox" name="usesig" id="usesig" class="pc" value="1" {if !$_G['group']['maxsigsize']}disabled {else}$usesigcheck {/if}/>{lang post_show_sig}</label></li>
		</ul>
		<ul class="mt10 cl">
			<li>
			<!--{if ($_G['forum']['allowhtml'] || ($_GET['action'] == 'edit' && ($orig['htmlon'] & 1))) && $_G['group']['allowhtml']}-->
				<label for="htmlon"><input type="checkbox" name="htmlon" id="htmlon" class="pc" value="1" $htmloncheck />{lang post_html}</label>
			<!--{else}-->
				<label for="htmlon"><input type="checkbox" name="htmlon" id="htmlon" class="pc" value="0" $htmloncheck disabled="disabled" />{lang post_html}</label>
			<!--{/if}-->
			</li>
			<li>
				<label for="allowimgcode"><input type="checkbox" id="allowimgcode" class="pc" disabled="disabled"{if $_G['forum']['allowimgcode']} checked="checked"{/if} />{lang post_imgcode}</label>
			</li>
			<!--{if $_G['forum']['allowimgcode']}-->
			<li>
				<label for="allowimgurl"><input type="checkbox" id="allowimgurl" class="pc" checked="checked" />{lang post_imgurl}</label>
			</li>
			<!--{/if}-->
			<li>
				<label for="parseurloff"><input type="checkbox" name="parseurloff" id="parseurloff" class="pc" value="1" $urloffcheck />{lang disable}{lang post_parseurl}</label>
			</li>
			<li>
				<label for="smileyoff"><input type="checkbox" name="smileyoff" id="smileyoff" class="pc" value="1" $smileyoffcheck />{lang disable}{lang smilies}</label>
			</li>
			<li>
				<label for="bbcodeoff"><input type="checkbox" name="bbcodeoff" id="bbcodeoff" class="pc" value="1" $codeoffcheck />{lang disable}{lang discuzcode}</label>
			</li>
			<li>
			<!--{if $_G['group']['allowimgcontent']}-->
				<label for="imgcontent"><input type="checkbox" name="imgcontent" id="imgcontent" class="pc" value="1" $imgcontentcheck onclick="switchEditor(this.checked?0:1);$('e_switchercheck').checked=this.checked;" />{lang content_to_pic}</label>
			<!--{else}-->
				<label for="imgcontent"><input type="checkbox" name="imgcontent" id="imgcontent" class="pc" value="0" $imgcontentcheck disabled="disabled"/>{lang content_to_pic}</label>
			<!--{/if}-->
			</li>
		</ul>
			<!--{if $_GET['action'] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts'])}-->
				<!--{if $_GET['action'] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts']) && ($_G['group']['allowstickthread'] || $_G['group']['allowdigestthread'])}-->
				<ul class="mt10 cl">
							<!--{if $_G['group']['allowstickthread']}-->
								<li><label for="sticktopic"><input type="checkbox" name="sticktopic" id="sticktopic" class="pc" value="1" $stickcheck />{lang post_stick_thread}</label></li>
							<!--{/if}-->
							<!--{if $_G['group']['allowdigestthread']}-->
								<li><label for="addtodigest"><input type="checkbox" name="addtodigest" id="addtodigest" class="pc" value="1" $digestcheck />{lang post_digest_thread}</label></li>
							<!--{/if}-->
				</ul>
				<!--{/if}-->
			<!--{elseif $_GET[action] == 'edit' && $_G['forum_auditstatuson']}-->
				<li class="mtit">{lang manage_operation}</li>
				<ul class="flex-box flex-wrap p10 cl">
					<li><label for="audit"><input type="checkbox" name="audit" id="audit" class="pc" value="1">{lang auditstatuson}</label></li>
				</ul>
			<!--{/if}-->
	</div>
	<!--{if $_GET['action'] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
		<!--{if $_G['group']['allowsetreadperm']}-->
			<div id="extra_readperm_c" class="yide_extra_readperm exfm cl" style="display:none">
				<ul class="cl">
					<li class="flex-box mli">
						<div class="tit">{lang readperm}:</div>
						<div class="flex input">
						<select name="readperm" id="readperm" class="sort_sel">
							<option value="">{lang unlimited}</option>
							<!--{loop $_G['cache']['groupreadaccess'] $val}-->
								<option value="$val[readaccess]"{if $thread['readperm'] == $val['readaccess']} selected="selected"{/if}>$val['grouptitle']</option>
							<!--{/loop}-->
							<option value="255"{if $thread['readperm'] == 255} selected="selected"{/if}>{lang highest_right}</option>
						</select>
						</div>
					</li>
				</ul>
				<div class="mtit mt10"><i class="ydicon icon-ydwarning"></i><span class="xg1">{lang post_select_usergroup_readacces}</span></div>
			</div>
		<!--{/if}-->

		<!--{if !empty($userextcredit)}-->
			<div id="extra_replycredit_c" class="yide_extra_replycredit exfm cl" style="display: none;">
				<ul class="cl">
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{$yide_mnav_020}:</div>
							<div class="flex input"><input type="text" name="replycredit_extcredits" id="replycredit_extcredits" class="px pxs vm" value="{if !empty($replycredit_rule['extcredits']) && $thread['replycredit'] > 0}{$replycredit_rule['extcredits']}{else}0{/if}" onkeyup="javascript:getreplycredit();" /></div>
							<div class="tit2">{$_G['setting']['extcredits'][$extcreditstype][unit]}{$_G['setting']['extcredits'][$extcreditstype][title]}</div>
						</div>
					</li>
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{$yide_mnav_021}:</div>
							<div class="flex input"><input type="text" name="replycredit_times" id="replycredit_times" class="px pxs vm" value="{if !empty($replycredit_rule['lasttimes'])}{$replycredit_rule['lasttimes']}{else}1{/if}" onkeyup="javascript:getreplycredit();" /></div>
							<div class="tit2">{lang replycredit_time}</div>
						</div>
					</li>
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{$yide_mnav_022}:</div>
							<div class="flex input">
								<select id="replycredit_membertimes" name="replycredit_membertimes" class="sort_sel vm">
									<!--{eval for($i=1;$i<11;$i++) {;}-->
										<option value="$i"{if isset($replycredit_rule['membertimes']) && $replycredit_rule['membertimes'] == $i} selected="selected"{/if}>$i</option>
									<!--{eval };}-->
								</select>
							</div>
							<div class="tit2">{lang replycredit_time}</div>
						</div>
					</li>
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{$yide_mnav_023}:</div>
							<div class="flex input">
								<select id="replycredit_random" name="replycredit_random" class="sort_sel vm">
									<!--{eval for($i=100;$i>9;$i=$i-10) {;}-->
										<option value="$i"{if isset($replycredit_rule['random']) && $replycredit_rule['random'] == $i} selected="selected"{/if}>$i</option>
									<!--{eval };}-->
								</select>
							</div>
							<div class="tit2">%</div>
						</div>
					</li>
				</ul>
				<div class="mtit xg1"><i class="ydicon icon-ydwarning"></i>{lang replycredit_total} <span id="replycredit_sum"><!--{if !empty($thread['replycredit'])}-->{$thread['replycredit']}<!--{else}-->0<!--{/if}--></span> {$_G['setting']['extcredits'][$extcreditstype][unit]}{$_G['setting']['extcredits'][$extcreditstype][title]}<!--{if !empty($thread['replycredit'])}--><span class="xg1">({lang replycredit_however} {$thread['replycredit']} {$_G['setting']['extcredits'][$extcreditstype][unit]}{$_G['setting']['extcredits'][$extcreditstype][title]})</span><!--{/if}-->, <span id="replycredit">{lang replycredit_revenue} {$_G['setting']['extcredits'][$extcreditstype][title]} 0</span> {$_G['setting']['extcredits'][$extcreditstype][unit]}, {lang you_have} {$_G['setting']['extcredits'][$extcreditstype][title]} $userextcredit {$_G['setting']['extcredits'][$extcreditstype][unit]}</div>
			</div>
		<!--{/if}-->
		
		<!--{if ($_GET['action'] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
			<div id="extra_rushreplyset_c" class="yide_extra_rushreplyset exfm cl" style="display: none;">
				<ul class="cl">
					<li class="mli"><label for="rushreply"><input type="checkbox" name="rushreply" id="rushreply" class="pc vm" value="1" {if $_GET['action'] == 'edit' && getstatus($thread['status'], 3)}disabled="disabled" checked="checked"{/if} /> {lang rushreply_change}</label></li>
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{$yide_mnav_024}:</div>
							<div class="flex"><input type="text" name="rushreplyfrom" id="rushreplyfrom" class="px" autocomplete="off" value="{$postinfo['rush']['starttimefrom'] or ''}" onkeyup="getID('rushreply').checked = true;" /></div>
						</div>
					</li>
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{$yide_mnav_025}:</div>
							<div class="flex"><input type="text" autocomplete="off" id="rushreplyto" name="rushreplyto" class="px" value="{$postinfo['rush']['starttimeto'] or ''}" onkeyup="getID('rushreply').checked = true;" /></div>
						</div>
					</li>
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{$yide_mnav_026}:</div>
							<div class="flex"><input type="text" name="rewardfloor" id="rewardfloor" class="px oinf" value="{$postinfo[rush][rewardfloor] or ''}" onkeyup="$('rushreply').checked = true;" /></div>
						</div>
					</li>
					<div class="mtit mb10 xg1"><i class="ydicon icon-ydwarning"></i>{lang rushreply_rewardfloor_comment}</div>
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{$yide_mnav_027}:</div>
							<div class="flex"><input type="text" name="replylimit" id="replylimit" class="px" autocomplete="off" value="{$postinfo[rush][replylimit] or ''}" onkeyup="$('rushreply').checked = true;" /></div>
						</div>
					</li>
					<div class="mtit mb10 xg1"><i class="ydicon icon-ydwarning"></i>{lang replylimit}</div>
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{lang rushreply_end}:</div>
							<div class="flex"><input type="text" name="stopfloor" id="stopfloor" class="px" autocomplete="off" value="{$postinfo[rush][stopfloor] or ''}" onkeyup="$('rushreply').checked = true;" /></div>
						</div>
					</li>
					<li class="mli">
						<div class="flex-box">
							<div class="tit"><!--{if !empty($_G['setting']['creditstransextra'][11])}-->{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]}<!--{else}-->{lang credits}<!--{/if}-->{lang min_limit}:</div>
							<div class="flex"><input type="text" name="creditlimit" id="creditlimit" class="px" autocomplete="off" value="{$postinfo[rush][creditlimit] or ''}" onkeyup="$('rushreply').checked = true;" /></div>
						</div>
					</li>
					<div class="mtit mb10 xg1"><i class="ydicon icon-ydwarning"></i><!--{if !empty($_G['setting']['creditstransextra'][11])}-->({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]})<!--{else}-->{lang total_credits}<!--{/if}-->{lang post_rushreply_credit}</div>
				</ul>
			</div>
		<!--{/if}-->
		<!--{if $_G['group']['maxprice'] && !$special}-->
			<div id="extra_price_c" class="yide_extra_price exfm cl" style="display:none">
				<ul class="cl">
					<li class="mli">
						<div class="flex-box">
							<div class="tit">{lang price}:</div>
							<div class="flex input">
								<input type="text" id="price" name="price" class="px pxs" value="$thread[pricedisplay]" />
							</div>
							<div class="pipe">
								{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}
							</div>
						</div>
					</li>
				</ul>
				<div class="mtit"><i class="ydicon icon-ydwarning"></i><span class="xg1">{lang post_price_comment}</span></div>
				<!--{if $_G['group']['maxprice'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
					<!--{if $_G['setting']['maxincperthread']}-->
						<div class="mtit"><i class="ydicon icon-ydwarning"></i><span class="xg1">{lang post_price_income_comment}</span></div>
					<!--{/if}-->
					<!--{if $_G['setting']['maxchargespan']}-->
						<div class="mtit"><i class="ydicon icon-ydwarning"></i><span class="xg1">{lang post_price_charge_comment}<!--{if $_GET[action] == 'edit' && $freechargehours}-->{lang post_price_free_chargehours}<!--{/if}--></span></div>
					<!--{/if}-->
				<!--{/if}-->
			</div>
		<!--{/if}-->

		<!--{if $_G['group']['allowposttag']}-->
			<div id="extra_tag_c" class="yide_extra_tag exfm cl" style="display: none;">
				<ul class="cl">
					<li class="mli">
						<div class="flex-box">
						<div class="tit">{lang post_tag}:</div>
						<div class="flex input"><input type="text" class="px vm" size="60" id="tags" name="tags" value="{$postinfo[tag] or ''}" /></div>
					</li>
				</ul>
				<div class="mtit"><i class="ydicon icon-ydwarning"></i><p class="xg1">{lang posttag_comment}</p></div>
			</div>
		<!--{/if}-->
		<!--{if $_G['group']['allowsetpublishdate'] && ($_GET['action'] == 'newthread' || ($_GET['action'] == 'edit' && $isfirstpost && $thread['displayorder'] == -4))}-->
			<div id="extra_pubdate_c" class="exfm cl" style="display: none;">
				<label><input type="checkbox" name="cronpublish" onclick="if(this.checked) {getID('cronpublishdate').click();doane(event,false);};hidenFollowBtn(this.checked);" id="cronpublish" value="true" class="pc"{if $cronpublish} checked="checked"{/if} />{lang post_timer}</label>
				<input type="text" name="cronpublishdate" id="cronpublishdate" class="px" autocomplete="off" value="{$cronpublishdate}" onchange="if(this.value) getID('cronpublish').checked = true;">
			</div>
		<!--{/if}-->
	<!--{/if}-->
	<!--{hook/post_attribute_extra_body_mobile}-->
</div>
<script type="text/javascript">
	function showExtra(id) {
		if ($('#'+id+'_c').css('display') == 'block') {
			$('#'+id+'_c').css({'display':'none'});
		} else {
			var extraButton = $('#post_extra_tb').children('li');
			var extraForm = $('#post_extra_c').children('div');
			
			$.each($('#post_extra_c > div'), function(){
				if($(this).hasClass('exfm')) {
					$(this).css({'display':'none'});
				}
			});
			$('#'+id+'_b').addClass('mon').siblings().removeClass('mon');
			$('#'+id+'_c').css({'display':'block'});
		}
	}
</script>
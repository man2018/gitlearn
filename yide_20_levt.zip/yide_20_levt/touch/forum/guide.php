<?php exit('Access Denied');?>	
<!--{template common/header}-->
<style>
	body{padding-top: 91px;}
</style>
<!--{if $_G['setting']['mobile']['forum']['index'] == 1 && empty($_G['cache']['heats']['message']) && $_GET['forumlist'] != 1}-->
	<div class="header header_white cl">
		<div class="mzlogo"><a href="javascript:;"><img src="$_G['style']['styleimgdir']/images/logo_m.png" /></a></div>
		<div class="myss"><a href="search.php?mod=forum"><i class="dm-search"></i>{lang mobsearchtxt}</a></div>
	</div>

	<!-- Tab start -->
	<div class="yide_threadlist_tab cl">
		<ul class="yide-tab-title cl">
			<li class="{if $view == 'newthread'}a{/if}"><a href="forum.php?mod=guide&view=newthread">{lang mobhome}<em></em></a></li>
			<li class="{if $view == 'new'}a{/if}"><a href="forum.php?mod=guide&view=new">$yide_mnav_035<em></em></a></li>
			<li class="{if $view == 'hot'}a{/if}"><a href="forum.php?mod=guide&view=hot">$yide_mnav_036<em></em></a></li> 
			<li class="{if $view == 'digest'}a{/if}"><a href="forum.php?mod=guide&view=digest">$yide_mnav_018<em></em></a></li> 
			<li class="{if CURSCRIPT == 'forum' && CURMODULE == 'index'}a{/if}"><a href="forum.php?forumlist=1">$yide_mnav_037<em></em></a></li> 
		</ul>
	</div>
	<!-- Tab end -->

	<!--{template yide_zdy/zdy_swiper}-->
	<!--{template yide_zdy/zdy_three}-->
	<!--{template forum/announces}-->
	<!--{template yide_zdy/zdy_four}-->
	<!--{template yide_zdy/zdy_banner}-->
<!--{else}-->
	<div class="header cl">
		<div class="mz">
			<a href="javascript:history.back();"><i class="dm-c-left"></i></a>
		</div>
		<h2>{$_G['setting']['navs'][2]['navname']}{lang guide}</h2>
		<div class="my"></div>
	</div>
	<div class="dhnv flex-box cl">
		<a href="forum.php?mod=guide&view=newthread" class="flex<!--{if $currentview['newthread']}--> mon<!--{/if}-->">{lang latest}</a>
		<a href="forum.php?mod=guide&view=hot" class="flex<!--{if $currentview['hot']}--> mon<!--{/if}-->">{lang order_heats}</a>
		<a href="forum.php?mod=guide&view=digest" class="flex<!--{if $currentview['digest'] }--> mon<!--{/if}-->">{lang digest}</a>
		<a href="forum.php?mod=guide&view=new" class="flex<!--{if $currentview['new']}--> mon<!--{/if}-->">{lang join_thread}</a>	
		<a href="forum.php?mod=guide&view=sofa" class="flex<!--{if $currentview['sofa']}--> mon<!--{/if}-->">{lang guide_sofa}</a>
	</div>
<!--{/if}-->
<!--{loop $data $key $list}-->
	<!--{subtemplate forum/guide_list_row}-->
<!--{/loop}-->
</div>
$multipage

<!--{template common/footer}-->
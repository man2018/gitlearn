<?php exit('Access Denied');?>
<!--{template common/header}-->
{eval}
$cates = C::t('portal_category')->range_category(0, 999);
foreach($cates as $cate){
	if(!$cate['closed'] && !$cate['upid']){
		$catelist[] = $cate;
	}
}
{/eval}
<!--{eval $page = isset($_GET['page']) ? intval($_GET['page']) : 1;}-->

<div class="header header_white cl">
	<div class="mzlogo"><a title="$_G['setting']['bbname']" href="javascript:;"><img src="$_G['style']['styleimgdir']/images/logo_m.png" /></a></div>
	<div class="myss"><a href="search.php?mod=portal"><i class="dm-search"></i>{lang mobsearchtxt}</a></div>
</div>

<!--{if $catelist && $_G['setting']['mobile']['portal']['catnav']}-->
	<div class="dhnavs_box">
		<div id="dhnavs">
			<div id="dhnavs_li">
				<ul class="swiper-wrapper">
					<!--{eval $i = 1;}-->
					<!--{loop $catelist $value}-->
						<li class="swiper-slide"><!--{if $i != 1}--><span>|</span><!--{/if}--><a href="{$_G['cache']['portalcategory'][$value['catid']]['caturl']}">$value['catname']</a></li>
					<!--{eval $i--;}-->
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<script>
		var swiper_catnav = new Swiper('#dhnavs_li', {
			freeMode : true,
			slidesPerView : 'auto',
			onTouchMove: function(swiper){
				Discuz_Touch_on = 0;
			},
			onTouchEnd: function(swiper){
				Discuz_Touch_on = 1;
			},
		});
	</script>
<!--{/if}-->

<!--{hook/portal_index_top_mobile}-->

<!--{if $page == 1 && $_G['setting']['mobile']['portal']['wzpicture']}-->
	<!--{eval $imglist = portal_get_list(1, 5, "at.pic != ''");}-->
	<!--{if count($imglist['list'])}-->
		<div class="yide_slide_wrap cl">
			<div class="dz-swiper_box dz-swiper">
				<ul class="swiper-wrapper">
					<!--{loop $imglist['list'] $value}-->
						<!--{eval $article_url = fetch_article_url($value);}-->
						<!--{eval $valuepic = str_replace('.thumb.jpg', '', $value['pic']);}-->
						<li class="swiper-slide">
							<a href="$article_url" style="background-image: url({$valuepic});">
								<span>$value['title']</span>
							</a>
						</li>
					<!--{/loop}-->
				</ul>
				<div class="swiper-forum"></div>
			</div>
			<div class="yide_wave_wrap cl">
				<div class="wave_top"></div>
				<div class="wave_bottom"></div>
			</div>
		</div>
		<script type="text/javascript">
			var swiper_slide = new Swiper('.dz-swiper',{
				initialSlide:0,
				direction: 'horizontal',
				loop: true,
				speed: 300,
				autoplay: {
					disableOnInteraction: false,
					delay: 2500,
				},
				pagination: {
					el: '.swiper-forum',
					type: 'fraction',
				},
			});
		</script>
	<!--{/if}-->
<!--{else}-->
	<!--{template yide_zdy/zdy_swiper}-->
<!--{/if}-->

<!--{template yide_zdy/zdy_three}-->
<!--{template forum/announces}-->
<!--{template yide_zdy/zdy_four}-->
<!--{template yide_zdy/zdy_banner}-->

<!--{hook/portal_index_middle_mobile}-->

<!--{if $_G['setting']['mobile']['portal']['wzlist']}-->
	<!--{eval}-->
		$list = array();
		$list = portal_get_list($page);
	<!--{/eval}-->
	<!--{if count($list['list'])}-->
		<div class="wzlist white_bg mt10 border_t cl">
			<!--{loop $list['list'] $value}-->
				<!--{eval}-->
					$highlight = article_title_style($value);
					$article_url = fetch_article_url($value);
				<!--{/eval}-->
				<li>
					<a href="$article_url" $highlight>
						<!--{if $value['pic']}--><div class="mimg"><img src="$value['pic']" alt="$value['title']" /></div><!--{/if}-->
						<div class="minfo"{if !$value['pic']} style="height: auto;"{/if}>
							<p class="mtit">$value['title']</p>
							<p class="mtime"{if !$value['pic']} style="position: unset;bottom: 0;"{/if}>$value['dateline']<!--{if $value['status'] == 1}--> <span>{lang moderate_need}</span><!--{/if}--><em class="y">#$value['catname']</em></p>
						</div>
					</a>
				</li>
			<!--{/loop}-->
		</div>
	<!--{else}-->
		<div class="threadlist_box mt10 cl">
			<div class="threadlist cl">
				<ul>
					<h4>{lang mobnodata}</h4>
				</ul>
			</div>
		</div>
	<!--{/if}-->
	<!--{if $list['multi']}-->{$list['multi']}<!--{/if}-->
	<script>
		var flowpage = $page;
		var mobnodata = '{lang mobnodata}';
		portal_flowlazyload();
	</script>
<!--{/if}-->

<!--{hook/portal_index_bottom_mobile}-->

<!--{template common/footer}-->
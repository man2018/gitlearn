<?php exit('Access Denied');?>	
<!--{echo output_ajax()}-->]]></root><!--{eval exit;}-->
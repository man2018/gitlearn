<?php exit('Access Denied');?>	
<!--{template common/header}-->
<div id="ct" class="wp cl ptw pbw">
	<table style="margin:0 auto"><tr><td>
	<div class="z dzphone"><div>
		<div class="scrtop">
			<div class="cl"><div class="time"><!--{echo date('H:i')}--></div><div class="defect"></div></div>
			<div class="siteurl"><!--{$_G['siteurl']}--></div>
		</div>
		<iframe id="ifm0" frameborder="0" src="misc.php?mod=mobile&view=true"></iframe>
		<div class="homebar"></div>
	</div></div>
	<div class="z" style="margin-top: 60px; width: 430px;">
		<div class="mtw bm bw0" style="background-color: #dfeaf4;">
			<div class="bm_c">
				<h1 class="xw1 xs2 mbn">{lang login_mobile}</h1>
				<p class="mbw xg2">{lang login_mobile_join}</p>
				<p class="hm mbw" style="font-size: 18px; color: #F60;">
					<img src="data/cache/$file" />
				</p>
			</div>
		</div>
	</div></td></tr></table>
</div>
<!--{template common/footer}-->
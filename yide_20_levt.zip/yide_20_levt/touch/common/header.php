<?php exit('Access Denied');?>	
<!DOCTYPE html>
<html>
<head>
<!--{eval}--> 
	include TPLDIR.'/lang/yd.language.'.currentlang().'.php'; 
	include TPLDIR.'/php/yide_set.php'; 
<!--{/eval}--> 
<meta charset="utf-8">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile']['mobilecachetime'] > 0}{$_G['setting']['mobile']['mobilecachetime']}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by Discuz!</title>
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
$_G['setting']['seohead']
<base href="{$_G['siteurl']}" />
<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '{$_G['uid']}', cookiepre = '{$_G['config']['cookie']['cookiepre']}', cookiedomain = '{$_G['config']['cookie']['cookiedomain']}', cookiepath = '{$_G['config']['cookie']['cookiepath']}', showusercard = '{$_G['setting']['showusercard']}', attackevasive = '{$_G['config']['security']['attackevasive']}', disallowfloat = '{$_G['setting']['disallowfloat']}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G['style']['defaultextstyle']', REPORTURL = '$_G['currenturl_encode']', SITEURL = '$_G['siteurl']', JSPATH = '$_G['setting']['jspath']';</script>
<link rel="stylesheet" href="$_G['style']['styleimgdir']/css/style.css?{VERHASH}" type="text/css" media="all">
<link rel="stylesheet" href="$_G['style']['styleimgdir']/font/dzmicon.css?{VERHASH}" type="text/css" media="all">
<link rel="stylesheet" href="$_G['style']['styleimgdir']/font/iconfont.css?{VERHASH}" type="text/css" media="all">
<link rel="stylesheet" href="$_G['style']['styleimgdir']/css/swiper.min.css" />

<script src="$_G['style']['styleimgdir']/js/jquery.min.js?{VERHASH}"></script>
<script src="$_G['style']['styleimgdir']/js/common.js?{VERHASH}" charset="{CHARSET}"></script>
<script src="$_G['style']['styleimgdir']/swiper/swiper-bundle.min.js?{VERHASH}"></script>
</head>
<body id="{$_G['basescript']}" class="pg_{CURMODULE}">
<!--{hook/global_header_mobile}-->
<div id="append_parent"></div>

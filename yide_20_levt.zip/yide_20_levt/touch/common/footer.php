<?php exit('Access Denied');?>	
<!--{hook/global_footer_mobile}-->
<div id="mask" style="display:none;"></div>
<!--{if $_G['setting']['statcode']}--><div id="statcode" style="display:none;">{$_G['setting']['statcode']}</div><!--{/if}-->
<!--{if !$nofooter}-->
	<div class="foot_height"></div>
	<div class="foot flex-box">
		<a href="{if $yide_home_style==1}portal.php{elseif $yide_home_style==2}forum.php?mod=guide&view=newthread{else}index.php{/if}" class="flex{if ($yide_home_style==1 && CURSCRIPT == 'portal' && CURMODULE == 'index') || ($yide_home_style==2 && CURSCRIPT == 'forum' && $_GET['mod'] == 'guide') || ($yide_home_style==3 && CURSCRIPT == 'forum' && CURMODULE == 'index')} mon{/if}">
			<span class="foot-ico"><em class="ma"></em></span>
			<span class="foot-txt">{lang mobhome}</span>
		</a>
		<!--{if $yide_home_style==1 || $yide_home_style==2}-->
			<a href="forum.php?forumlist=1" class="flex<!--{if CURSCRIPT == 'forum' && $_GET['forumlist'] == '1'}--> mon<!--{/if}-->" >
				<span class="foot-ico"><em class="mb"></em></span>
				<span class="foot-txt">{$yide_mnav_033}</span>
			</a>
		<!--{else}-->
			<a href="forum.php?mod=guide&view=newthread" class="flex<!--{if CURSCRIPT == 'forum' && $_GET['mod'] == 'guide'}--> mon<!--{/if}-->" >
				<span class="foot-ico"><em class="mb"></em></span>
				<span class="foot-txt">{$yide_mnav_034}</span>
			</a>
		<!--{/if}-->
		<a href="forum.php?mod=misc&action=nav" class="flex foot-post">
			<span class="foot-ico"><em class="mc"></em></span>
			<span class="foot-txt">{lang mobpost}</span>
		</a>
		<a href="forum.php?mod=find" class="flex{if $_G['basescript'] == 'forum' && $_GET['mod'] == 'find'} mon{/if}">
			<span class="foot-ico"><em class="md"></em></span>
			<span class="foot-txt">{lang mobfind}</span>
		</a>
		<a href="{if $_G['uid']}home.php?mod=space&uid={$_G['uid']}&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}" class="flex{if $_G['basescript'] == 'home' && CURMODULE == 'space' && $_GET['mycenter'] == 1} mon{/if}">
			<span class="foot-ico"><em class="me">
			<!--{if strpos('forum.php', $_G['setting']['defaultindex']) === false || helper_access::check_module('portal') || helper_access::check_module('group') || helper_access::check_module('feed')}-->
				<!--{if $_G['uid'] && ($_G['member']['newpm'] || $_G['member']['newprompt'])}--><i class="ico_msg"></i><!--{/if}-->
			<!--{/if}-->
			</em></span>
			<span class="foot-txt">{lang mobmy}</span>
		</a>
	</div>
<!--{/if}-->

</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')&&!defined('IN_PREVIEW')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->

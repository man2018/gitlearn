<?php
/**
* Main CSS file for Discuz! X
* 模板版权 by 艺迪工作室
* 客服QQ:2542274606
**/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$yide_mnav_001 = '每日上新';
$yide_mnav_002 = '海量最新资讯播报';
$yide_mnav_003 = '发现更多';
$yide_mnav_004 = '有意思的话题时刻聊';
$yide_mnav_005 = '精彩活动';
$yide_mnav_006 = '超级福利聚集地';
$yide_mnav_007 = '公告';

$yide_mnav_008 = '探秘数据';
$yide_mnav_009 = '看帖赚钱';
$yide_mnav_010 = '实时观看';
$yide_mnav_011 = '数据看板';
$yide_mnav_012 = '积分礼品';
$yide_mnav_013 = '';
$yide_mnav_014 = '';
$yide_mnav_015 = '';
$yide_mnav_016 = '广告';
$yide_mnav_017 = '查看电脑版';
$yide_mnav_018 = '精华';
$yide_mnav_019 = '点我插入';

$yide_mnav_020 = '回帖奖励';
$yide_mnav_021 = '奖励次数';
$yide_mnav_022 = '最多可得';
$yide_mnav_023 = '中奖概率';
$yide_mnav_024 = '抢楼开始';
$yide_mnav_025 = '抢楼结束';
$yide_mnav_026 = '奖励楼层';
$yide_mnav_027 = '截止楼层';

$yide_mnav_028 = '热门搜索';
$yide_mnav_029 = '门户首页静态幻灯自定义广告语一';
$yide_mnav_030 = '门户首页静态幻灯自定义广告语二';
$yide_mnav_031 = '门户首页静态幻灯自定义广告语三';
$yide_mnav_032 = '门户首页静态幻灯自定义广告语四';

$yide_mnav_033 = '论坛';
$yide_mnav_034 = '导读';
$yide_mnav_035 = '新回复';
$yide_mnav_036 = '热门';
$yide_mnav_037 = '版块';

?>
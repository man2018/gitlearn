<?php
/**
* Main CSS file for Discuz! X
* 模板版權 by 藝迪工作室
* 客服QQ:2542274606
**/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$yide_mnav_001 = '每日上新';
$yide_mnav_002 = '海量最新資訊播報';
$yide_mnav_003 = '發現更多';
$yide_mnav_004 = '有意思的話題時刻聊';
$yide_mnav_005 = '精彩活動';
$yide_mnav_006 = '超級福利聚集地';
$yide_mnav_007 = '公告';

$yide_mnav_008 = '探秘數據';
$yide_mnav_009 = '看帖賺錢';
$yide_mnav_010 = '實時觀看';
$yide_mnav_011 = '數據看板';
$yide_mnav_012 = '積分禮品';
$yide_mnav_013 = '';
$yide_mnav_014 = '';
$yide_mnav_015 = '';
$yide_mnav_016 = '廣告';
$yide_mnav_017 = '查看電腦版';
$yide_mnav_018 = '精華';
$yide_mnav_019 = '點我插入';

$yide_mnav_020 = '回帖獎勵';
$yide_mnav_021 = '獎勵次數';
$yide_mnav_022 = '最多可得';
$yide_mnav_023 = '中獎概率';
$yide_mnav_024 = '搶樓開始';
$yide_mnav_025 = '搶樓結束';
$yide_mnav_026 = '獎勵樓層';
$yide_mnav_027 = '截止樓層';

$yide_mnav_028 = '熱門搜索';
$yide_mnav_029 = '門戶首頁靜態幻燈自定義廣告語一';
$yide_mnav_030 = '門戶首頁靜態幻燈自定義廣告語二';
$yide_mnav_031 = '門戶首頁靜態幻燈自定義廣告語三';
$yide_mnav_032 = '門戶首頁靜態幻燈自定義廣告語四';

$yide_mnav_033 = '論壇';
$yide_mnav_034 = '導讀';
$yide_mnav_035 = '新回復';
$yide_mnav_036 = '熱門';
$yide_mnav_037 = '版塊';

?>
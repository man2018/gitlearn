<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}

$announcedata = C::t('forum_announcement')->fetch_all_by_date($_G['timestamp']);
if($announcedata) {
	$readapmids = !empty($_G['cookie']['readapmid']) ? explode('D', $_G['cookie']['readapmid']) : array();
	foreach($announcedata as $announce) {
		if(!$announce['endtime'] || $announce['endtime'] > TIMESTAMP && (empty($announce['groups']) || in_array($_G['member']['groupid'], $announce['groups']))) {
			if(empty($announce['type'])) {
				$announces .= '<li class="swiper-slide"><a href="forum.php?mod=announcement&id='.$announce['id'].'" class="swiper-slide">'.$announce['subject'].'</a></li>';
			}elseif($announce['type'] == 1) {
				$announces .= '<li class="swiper-slide"><a href="'.$announce['message'].'" target="_blank" class="swiper-slide">'.$announce['subject'].'</a></li>';
			}
		}
	}
}
	

?>






	var swiper_slide = new Swiper('.dz-swiper',{
		initialSlide:0,
		direction: 'horizontal',
		loop: true,
		speed: 300,
		autoplay: {
			disableOnInteraction: false,
			delay: 2500,
		},
		pagination: {
			el: '.swiper-forum',
			type: 'fraction',
		},
	});
